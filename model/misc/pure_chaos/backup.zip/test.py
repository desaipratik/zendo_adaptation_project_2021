from pcfg_generator import pcfg_generator
import pandas as pd
import numpy as np
from tree_regrower import tree_regrower
from reverse_rule import reverse_rule
from tree_surgery import tree_surgery
import random as rd
import copy

####################### grammar ##############################################
S = ['Z.exists(lambda xN: A,X)', 'Z.forall(lambda xN: A,X)', 'L(lambda xN: A,M,X)']
A = ['S', 'B']
B = ['C', 'J(B,B)', 'Z.not_operator(B)']
C = ['Z.equal(xN, D)', 'K(xN, E)', 'Z.equal(xN,xO,G)', 'K(xN, xO, H)', 'Z.hor_operator(xN,xO,I)']
D = {"colour": ["'red'", "'blue'", "'green'"], "size": [1, 2, 3], "xpos": np.arange(9),"ypos": np.arange(2, 6), "rotation": np.arange(0, 6.5, 0.5),"orientation": ["'upright'", "'lhs'", "'rhs'", "'strange'"], "grounded": ["'no'", "'yes'"]}
E = {"size": [1, 2, 3], "xpos": np.arange(9), "ypos": np.arange(2, 6), "rotation": np.arange(0, 6.3, 0.1)}
G = ["'colour'", "'size'", "'xpos'", "'ypos'", "'rotation'", "'orientation'", "'grounded'"]
H = ["'size'", "'xpos'", "'ypos'", "'rotation'"]
I = ["'contact'"]
J = ['Z.and_operator', 'Z.or_operator']
K = ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']
L = ['Z.atleast', 'Z.atmost', 'Z.exactly']
M = [1, 2, 3]

# summarizing grammar in dictionary
productions = {"S": S, "A": A, "B": B, "C": C, "D": D, "E": E, "G": G, "H": H, "I": I, "J": J, "K": K, "L": L, "M": M}

# replacement dictionary
rep = {"S": ['Z.exists','Z.forall','Z.atleast','Z.atmost','Z.exactly'],
                "L": ['Z.atleast','Z.atmost','Z.exactly'],
                "M": [1,2,3],
                "A": ['Z.exists','Z.forall','Z.atleast','Z.atmost','Z.exactly'],
                "B": ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater','Z.and_operator','Z.or_operator','Z.not_operator'],
                "C": ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']}

rep_new = {"S": ['Z.exists','Z.forall','Z.atleast','Z.atmost','Z.exactly'],
                "L": ['Z.atleast','Z.atmost','Z.exactly'],
                "M": [1,2,3],
                "A": ['Z.exists','Z.forall','Z.atleast','Z.atmost','Z.exactly'],
                "B": [["'(xN, D)'","'(xN,xO,G)'"], ["'(xN,xO,I)'","'(xN,xO,I)'"], ["'(xN,xO,H)'","'(xN, E)'"], ["'(xN,xO,H)'","'(xN, E)'"], ["'(xN,xO,H)'","'(xN, E)'"], ["'(xN,xO,H)'","'(xN, E)'"],'Z.and_operator','Z.or_operator','Z.not_operator'],
                "C": ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']}



# probabilities:
Swin =  {'Z.exists': 1/3, 'c': 1/3, 'L': 1/3, "A": 1}
Awin = {"B": 1/2, "S": 1/2}
Bwin = {'C': 1/3, 'J(B,B)': 1/3, 'Z.not_operator': 1/3}
Cwin = {'D': .2, 'E': .2, 'G': .2, 'H': .2, 'I': .2}
Dwin =  {"colour": {"feat": .25, "values": {"red": 1/3, "blue": 1/3, "green": 1/3}},
         "size": {"feat": .25, "values": {"1": 1/3, "2": 1/3, "3": 1/3}},
         "orientation": {"feat": .25, "values": {"upright": 1/4, "lhs": 1/4, "rhs": 1/4, "strange": 1/4}},
         "grounded": {"feat": .25, "values": {"no": .5, "yes": .5}}}
Ewin = {"size": {"feat": 1, "values": {"1": 1/3, "2": 1/3, "3": 1/3}}}
Gwin = {'colour': .25, 'size': .25, 'xpos': 0, 'ypos': 0, 'rotation': 0, 'orientation': .25, 'grounded': .25}
Hwin = {"size": 1}
Iwin = {"contact": 1}
Jwin =  {"Z.and_operator":.5,"Z.or_operator":.5}
Kwin =  {'Z.lequal': .25, 'Z.grequal': .25, 'Z.less': .25, 'Z.greater': .25}
Lwin =  {'Z.atleast': 1/3, 'Z.atmost': 1/3, 'Z.exactly': 1/3}
Mwin = {"1": 0.333333333,"2": 0.333333333, "3": 0.333333333}

# summarizing probs in dictionary
probabilities = {"S": Swin, "A": Awin, "B": Bwin, "C": Cwin,
                 "D": Dwin, "E": Ewin, "G": Gwin, "H": Hwin, "I": Iwin,
                 "J": Jwin, "K": Kwin, "L": Lwin, "M": Mwin}


Z = pcfg_generator()  # instantiating grammar generator (Z is an arbitrary choice, the letter G is already used in the grammar...)
tg = tree_regrower()  # instantiating tree regrower
rr = reverse_rule()
ts = tree_surgery()





X = [{'size': 3, 'colour': 'red'},{'size': 1, 'colour': 'blue'},{'size': 1, 'colour': 'blue'}]

# print(Z.forall(lambda x1: Z.forall(lambda x2: Z.or_operator(Z.and_operator(Z.greater(x1,x2,'size'), Z.equal(x2,'blue','colour')), Z.not_operator(Z.equal(x1,'red','colour'))),X),X))
# print(sum([True,False]))

 # return sum([func(i) for i in x]) == n
 # print(n)
 # print(sum([func(i) for i in x]))



# There needs to be 3 or less cones with 1 being a small blue

print(Z.atmost(lambda x1: Z.exists(lambda x2: Z.and_operator(Z.equal(x2, 'blue','colour'),Z.equal(x2, 1, 'size')),X),3,X))
print(tg.string_to_list("Z.atmost(lambda x1: Z.exists(lambda x2: Z.and_operator(Z.equal(x2, 'blue','colour'),Z.equal(x2, 1, 'size')),X),3,X)"))


t = {'rule': "Z.atmost(lambda x1: Z.exists(lambda x2: Z.and_operator(Z.equal(x2, 'blue','colour'),Z.equal(x2, 1, 'size')),X),3,X)"}
# print(ts.tree_surgery(productions,t,rep,rep_new))
# print(rr.get_prec_recursively(rr.string_to_list(t['rule'])))
t['prec'] = rr.get_prec_recursively(rr.string_to_list(t['rule']))
print(ts.tree_surgery(productions,t,rep,rep_new))

def exactly(func, n, x):
        """ exact quantifier """
        for i in x:
            print(i)
        print(sum([func(i) for i in x]) == n)
        print(n)
        return sum([func(i) for i in x]) == n


X = [{'size': 3, 'colour': 'red'},{'size': 1, 'colour': 'blue'},{'size': 1, 'colour': 'blue'}]

rule = 'there is a red'
# print(Z.exists(lambda x1: Z.equal(x1, 'red', 'colour'),X))










# #
# def exactly(self, func, n, x):
#     """ exact quantifier """
#     return sum([func(i) for i in x]) == n

# print(Z.exactly(lambda x1: True, 2 , X))


# print(tg.list_to_string(['Z.exists', ['lambda', 'x1', ':', 'Z.not_operator', ['Z.not_operator', ['Z.or_operator', ['Z.not_operator', ['Z.not_operator', ['Z.equal', ['x1', 'no', 'grounded']]], 'Z.less', ['x1', 'x1', 'size']], 'Z.equal', ['x1', 2, 'size']]], 'X']]))

#
# # # ts = tree_surg ery()
# #
# # def geta():
# #     t = Z.generate_res(productions, start="S", bound_vars=[], prec=pd.DataFrame({"from": [], "to": [], "toix": [], "li": []}))  # create an initial rule t
# #     # t_rule = "Z.forall(lambda x1: Z.not_operator(Z.and_operator(Z.equal(x1, 'yes','grounded'),Z.equal(x1, 'yes','grounded'))),X)"
# #     # t_rule = "Z.exists(lambda x1: Z.exactly(lambda x2: Z.or_operator(Z.equal(x2,x1,'colour'),Z.greater(x1,x2,'size')),1,X),X)"
# #     # t_prec = t['prec']
# #     # t_prod = t_prec['from']
# #     t_rule = t['rule']
# #     t_bv = t['bv']
# #     t_prime_bv = t_bv
# #
# #     # t_prime_info = tg.regrow_tree(t, productions, replacements) # details needed to generate a proposal
# #     # t_prime = Z.generate_res(productions, t_prime_info["t_prime_rule"],
# #     #                      bound_vars=t_prime_info["t_prime_bv"], prec=t_prime_info["t_prime_prec"])
# #
# #     t_prec = rr.get_prec_recursively(rr.string_to_list(t_rule))
# #     t_prime_bv = t_bv.copy()   # new bound variables (might be changed later)
# #     t_list = ts.string_to_list(t_rule)  # transforming rule into list of list
# #     ind_nested = ts.get_inds(t_list)    # gettinng elements and all nested indexes
# #     t_prod = t_prec["from"]
# #     # print(t_list)
# #
# #
# #     # then sampling new node and replacements
# #     t_prod_inds = list(range(0, len(t_prod)))
# #     nt_inds = [index for index,prod in zip(t_prod_inds,t_prod) if prod in ['B']]
# #     # print(t_rule)
# #
# #     nt_ind = rd.choice(nt_inds)     # selecting random nonterminal index from which tree will be regrown
# #     # print(t_prod)
# #     # nt_ind = 2
# #     nt = t_prod[nt_ind]
# #     # print(t_prod)
# #     # print(nt_ind)
# #
# #     # new_prod_prob = 1/len(productions[nt])
# #     cut = 0  # default variable that might change to 1 if nt is "S" (since then more needs to be removed from t_prec, see below)
# #     new_inds = [index for index,prod in zip(t_prod_inds,t_prod) if prod in [nt]] # getting indexes for B onl
# #     n_ind_select = new_inds.index(nt_ind)     # getting the exact B (ie which one from many has been chosen if many are available)
# #
# #     # print(t_prod)
# #     # now use the above to get the index of the selected be from the lists including all features
# #     all_inds = list(range(0, len(ind_nested)))
# #     nt_inds = [index for index,prod in zip(all_inds,ind_nested) if prod in replacements[nt]]
# #     spec_ind = ind_nested[nt_inds[n_ind_select]+1]
# #     spec_ind_l = [str([ind]) for ind in spec_ind]
# #     spec_ind_s = ''.join(spec_ind_l)
# #     t_prime_list = copy.deepcopy(t_list)
# #     spec_ind_s_copy = spec_ind_s
# #
# #     t_component = eval('t_list' + spec_ind_s)
# #     # print(t_component)
# #     # print(spec_ind_s)
# #     del(replacements_new[nt][replacements[nt].index(t_component)])
# #     del(replacements[nt][replacements[nt].index(t_component)])
# #
# #     if t_component == 'Z.not_operator':
# #         del(replacements_new[nt][replacements[nt].index('Z.and_operator')])
# #         del(replacements[nt][replacements[nt].index('Z.and_operator')])
# #         del(replacements_new[nt][replacements[nt].index('Z.or_operator')])
# #         del(replacements[nt][replacements[nt].index('Z.or_operator')])
# #         del(replacements[nt][replacements[nt].index('Z.hor_operator')])
# #
# #
# #
# #
# #     p_ind = rd.choice(list(range(0, len(replacements[nt]))))
# #     # p_ind = 2
# #     # print(replacements[nt])
# #     new_p = replacements[nt][p_ind]
# #     # print('ne')
# #     # print(new_p)
# #   # make sure to adjust for relaitonal stuff
# #
# #     # print(new_p)
# #     # new_p = 'Z.greater'
# #     # print(new_p)
# #     # replacing part of list with new part and removing the part immediately following the initial part
# #     exec('t_prime_list' + spec_ind_s + '=' + 'new_p')
# #     eval('print(t_list' + spec_ind_s + ')')
# #     # print
# #
# #
# #     # now conditional assignments:
# #     if nt == 'S':
# #         if t_component in ['Z.exists','Z.forall'] and new_p in ['Z.exists','Z.forall'] or t_component in ['Z.atleast','Z.atmost','Z.exactly'] and new_p in ['Z.atleast','Z.atmost','Z.exactly']:
# #             t_prime_rule = ts.list_to_string(t_prime_list)
# #             t_prime_prec = rr.get_prec_recursively(t_prime_list)
# #             t_prime_rule = tg.list_to_string(t_prime_list)
# #             # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
# #         elif t_component in ['Z.exists','Z.forall'] and new_p in ['Z.atleast','Z.atmost','Z.exactly']:
# #             print('hi')
# #             if n_ind_select == 0:
# #                 t_prime_list[1][-1] = rd.choice(productions["M"])
# #                 t_prime_list[1].append('X')
# #             elif n_ind_select == 1:
# #                 t_prime_list[1][4][-1] = rd.choice(productions["M"])
# #                 t_prime_list[1][4].append('X')
# #             elif n_ind_select == 2:
# #                 t_prime_list[1][4][4][-1] = rd.choice(productions["M"])
# #                 t_prime_list[1][4][4].append('X')
# #         elif t_component in ['Z.atleast','Z.atmost','Z.exactly'] and new_p in ['Z.exists','Z.forall']:
# #             if n_ind_select == 0:
# #                 del(t_prime_list[1][-2])
# #             elif n_ind_select == 1:
# #                 del(t_prime_list[1][4][-2])
# #             elif n_ind_select == 2:
# #                 del(t_prime_list[1][4][4][-2])
# #
# #         t_prime_rule = ts.list_to_string(t_prime_list)
# #         t_prime_prec = rr.get_prec_recursively(t_prime_list)
# #         t_prime_rule = tg.list_to_string(t_prime_list)
# # #         # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
# #
# #     if nt == 'L':
# #         t_prime_rule = ts.list_to_string(t_prime_list)
# #         t_prime_prec = rr.get_prec_recursively(t_prime_list)
# #         t_prime_rule = tg.list_to_string(t_prime_list)
# #         # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
# #
# #     if nt == 'M':
# #         if n_ind_select == 0:
# #             t_prime_list[1][-2] = rd.choice(replacements[nt])
# #         elif n_ind_select == 1:
# #             t_prime_list[1][4][-2] = rd.choice(replacements[nt])
# #         elif n_ind_select == 2:
# #             t_prime_list[1][4][4][-2] = rd.choice(replacements[nt])
# #         t_prime_rule = ts.list_to_string(t_prime_list)
# #         t_prime_prec = rr.get_prec_recursively(t_prime_list)
# #         t_prime_rule = tg.list_to_string(t_prime_list)
# #         # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
# #
# #     # print(t_component)
# #
# #     if nt == 'B':
# #
# #         # first if boolean extension just replace
# #         if t_component in ['Z.and_operator', 'Z.or_operator'] and new_p in ['Z.and_operator', 'Z.or_operator']:
# #             t_prime_rule = ts.list_to_string(t_prime_list)
# #             t_prime_prec = rr.get_prec_recursively(t_prime_list)
# #
# #
# #             # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
# #
# #         # easy for not operator
# #         if new_p in ['Z.not_operator'] and t_component in ['Z.and_operator', 'Z.or_operator']:
# #             spec_ind_l_2 = spec_ind.copy()
# #             spec_ind_l_2[-1] = spec_ind_l_2[-1] + 1
# #             spec_ind_l_2.append(spec_ind_l_2[-1] + 2)
# #             spec_ind_l_2 = [str([i]) for i in spec_ind_l_2[:len(spec_ind_l_2)-2]] + spec_ind_l_2[len(spec_ind_l_2)-2:]
# #             final_index = '[' + str(spec_ind_l_2[-2]) + ':' + str(spec_ind_l_2[-1]) + ']'
# #             spec_ind_l_2[len(spec_ind_l_2)-2:] = final_index
# #             spec_ind_s_2 = ''.join(spec_ind_l_2)
# #             new_list_ind = spec_ind[-1] + 1
# #             spec_ind_l = spec_ind_l[:len(spec_ind_l)-1]
# #             spec_ind_s = ''.join(spec_ind_l)
# #             exec('t_prime_list' + spec_ind_s + '.insert(new_list_ind,t_component)')
# #
# #             print(eval('t_prime_list' + spec_ind_s_2))
# #
# #
# #             exec('t_prime_list' +spec_ind_s_2+' = [t_prime_list' + spec_ind_s_2+']')
# #
# #
# #         elif new_p in ['Z.not_operator'] and t_component not in ['Z.and_operator', 'Z.or_operator']:
# #
# #             spec_ind_l_2 = spec_ind.copy()
# #             spec_ind_l_2[-1] = spec_ind_l_2[-1] + 1
# #             spec_ind_l_2.append(spec_ind_l_2[-1] + 2)
# #             spec_ind_l_2 = [str([i]) for i in spec_ind_l_2[:len(spec_ind_l_2)-2]] + spec_ind_l_2[len(spec_ind_l_2)-2:]
# #             final_index = '[' + str(spec_ind_l_2[-2]) + ':' + str(spec_ind_l_2[-1]) + ']'
# #
# #             spec_ind_l_2[len(spec_ind_l_2)-2:] = final_index
# #             spec_ind_s_2 = ''.join(spec_ind_l_2)
# #
# #
# #             new_list_ind = spec_ind[-1] + 1
# #             # spec_ind_l_2[-1] = str([new_list_ind])
# #
# #             spec_ind_l = spec_ind_l[:len(spec_ind_l)-1]
# #             spec_ind_s = ''.join(spec_ind_l)
# #
# #             exec('t_prime_list' + spec_ind_s + '.insert(new_list_ind,t_component)')
# #
# #             print(eval('t_prime_list' + spec_ind_s_2))
# #
# #
# #             exec('t_prime_list' +spec_ind_s_2+' = [t_prime_list' + spec_ind_s_2+']')
# #             print(t_prime_list)
# #
# #         # now check booleans vs single checks
# #         elif t_component in ['Z.and_operator', 'Z.or_operator'] and new_p in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']:
# #             first_component = spec_ind_l.copy()
# #             first_component[-1] = str([spec_ind[-1] + 1])
# #             first_component.append('[0]')
# #             second_component = spec_ind_l.copy()
# #             second_component[-1] = str([spec_ind[-1] + 1])
# #             second_component.append('[2]')
# #             first_component_s = ''.join(first_component)
# #             second_component_s = ''.join(second_component)
# #             f_c = eval('t_list' + first_component_s)
# #             s_c = eval('t_list' + second_component_s)
# #             if new_p == f_c:
# #                 exec('del(t_prime_list' + spec_ind_s + ')')
# #                 exec('del(t_prime_list' + spec_ind_s + '[2:])')
# #                 exec('t_prime_list' + spec_ind_s + '= eval(", ".join(repr(e) for e in t_prime_list' + spec_ind_s + '))')
# #             elif new_p == s_c:
# #                 exec('del(t_prime_list' + spec_ind_s + ')')
# #                 exec('del(t_prime_list' + spec_ind_s + '[:2])')
# #                 exec('t_prime_list' + spec_ind_s + '= eval(", ".join(repr(e) for e in t_prime_list' + spec_ind_s + '))')
# #                 print('asdfadfadsfadsf')
# #                 print(t_prime_list)
# #                 print(tg.list_to_string(t_prime_list))
# #             elif new_p != f_c and new_p != s_c:
# #                 exec('del(t_prime_list' + spec_ind_s + ')')
# #                 exec('del(t_prime_list' + spec_ind_s + '[:4])')
# #                 print(rd.choice(replacements_new[nt][p_ind]))
# #                 exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
# #
# #         # now check singles vs singles
# #         elif t_component in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater'] and new_p in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']:
# #             # check size comparison
# #             if t_component in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater'] and new_p in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.equal']:
# #                 t_prime_rule = tg.list_to_string(t_prime_list)
# #
# #                 # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_list": t_prime_list}
# #             # check equal comparison vs size
# #             elif t_component in ['Z.equal'] and new_p in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']:
# #                 # need to check if next item is size
# #                 size_check_ind = spec_ind_l.copy()
# #
# #                 size_check_ind[-1] = str([spec_ind[-1] + 1])
# #
# #                 size_check_ind_safe = size_check_ind.copy()
# #                 size_check_ind = size_check_ind + ['[2]']
# #                 size_check_ind_s = ''.join(size_check_ind)
# #                 print(t_prime_list)
# #                 print(size_check_ind_s)
# #                 if eval('t_prime_list' + size_check_ind_s) == 'size':
# #                     t_prime_rule = tg.list_to_string(t_prime_list)
# #                     # output = {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
# #                 else:
# #                     print(t_prime_list)
# #                     size_check_ind_s = ''.join(size_check_ind_safe)
# #                     exec('del(t_prime_list' + size_check_ind_s + ')')
# #                     print('hi')
# #                     print(t_prime_list)
# #
# #                     exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
# #
# #             elif t_component in ['Z.hor_operator'] and new_p in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.equal']:
# #                 exec('del(t_prime_list' + spec_ind_s + ')')
# #                 exec('del(t_prime_list' + spec_ind_s + '[:4])')
# #                 exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
# #
# #             elif t_component in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.equal'] and new_p in ['Z.hor_operator']:
# #                 exec('del(t_prime_list' + spec_ind_s + ')')
# #                 exec('del(t_prime_list' + spec_ind_s + '[:4])')
# #                 exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
# #
# #         # finally expansion check
# #         elif t_component in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater'] and new_p in ['Z.and_operator', 'Z.or_operator']:
# #             spec_ind_l_2 = spec_ind.copy()
# #             spec_ind_l_2[-1] = spec_ind_l_2[-1] + 1
# #             spec_ind_l_2.append(spec_ind_l_2[-1] + 3)
# #             spec_ind_l_2 = [str([i]) for i in spec_ind_l_2[:len(spec_ind_l_2)-2]] + spec_ind_l_2[len(spec_ind_l_2)-2:]
# #             final_index = '[' + str(spec_ind_l_2[-2]) + ':' + str(spec_ind_l_2[-1]) + ']'
# #             spec_ind_l_2[len(spec_ind_l_2)-2:] = final_index
# #             spec_ind_s_2 = ''.join(spec_ind_l_2)
# #             new_list_ind = spec_ind[-1] + 1
# #             spec_ind_l = spec_ind_l[:len(spec_ind_l)-1]
# #             spec_ind_s = ''.join(spec_ind_l)
# #             inser_index = spec_ind_l_2.copy()
# #             print(inser_index[-4])
# #             inser_index[-4] = int(inser_index[-4]) + 2
# #             # insert_index_s = ''.join(inser_index)
# #             # print(insert_index_s)
# #
# #             # print('asdfasdfadsfafadsfdfa')
# #             exec('t_prime_list' + spec_ind_s + '.insert(new_list_ind,t_component)')
# #             print(spec_ind_s)
# #             print(spec_ind_s_2)
# #             print(eval('t_prime_list' + spec_ind_s_2))
# #             exec('t_prime_list' + spec_ind_s + '.insert(inser_index[-4],"C")')
# #             print(t_prime_list)
# #             exec('t_prime_list' +spec_ind_s_2+' = [t_prime_list' + spec_ind_s_2+']')
# #
# #             print()
# #             print(t_prime_list)
# #             print('fail above')
# #
# #         # now what if old one was not operator -> delete this fellow:
# #         if t_component in ['Z.not_operator'] and new_p in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.and_operator', 'Z.or_operator']:
# #
# #             #just delete the fucking not operator and the replacement as well. thats what you will do
# #             # print(new_p)
# #             print('problem here')
# #             new_spec_ind = spec_ind.copy()
# #             new_spec_ind[-1] = new_spec_ind[-1] + 1
# #             new_spec_ind_2 = new_spec_ind.copy()
# #             new_spec_ind_2.append(1)
# #             new_spec_ind_l = [str([i]) for i in new_spec_ind]
# #             new_spec_ind_l_2 = [str([i]) for i in new_spec_ind_2]
# #             new_spec_ind_s = ''.join(new_spec_ind_l)
# #             new_spec_ind_s_2 = ''.join(new_spec_ind_l_2)
# #             t_prime_list2 = copy.deepcopy(t_prime_list)
# #             exec('del(t_prime_list' + spec_ind_s + ')')
# #             # print(t_prime_list)
# #             exec('t_prime_list' + spec_ind_s + '= t_prime_list' + spec_ind_s + '[0]')
# #             # t_prime_list[1][3] = t_prime_list[1][3][0]
# #             # print(t_prime_list)
# #             # print(t_prime_list2[1][4][1])
# #             spec_ind_2 = spec_ind_s[:-3]
# #
# #             # print(spec_ind_2)
# #
# #             # exec('del(t_prime_list' + spec_ind_s + ')')
# #             # print(t_prime_list2[1][3])
# #             spec_ind_3 = spec_ind_s[:-2] + str(int(spec_ind_s[-2]) + 1) + ']'
# #             # print(spec_ind_3)
# #             # print(eval('t_prime_list2' + spec_ind_3))
# #             exec('t_prime_list' + spec_ind_2 + '.insert(4, t_prime_list2' + spec_ind_3 + '[1])')
# #
# #             # eval(eval("str(['Z.forall', ['lambda', 'x1', ':'," + str(['Z.and_operator', ['Z.equal', ['x1', 'yes', 'grounded'], 'Z.grequal', ['x1', 1, 'size']]])[1:-1] +", 'X']])"))
# #
# #
# #
# #
# #
# #             # print(spec_ind_s)
# #             print(t_prime_list)
# #             # exec('t_prime_list' + spec_ind_s + '= t_prime_list'+spec_ind_s+'[0]')
# #             # print(t_prime_list[1][3])
# #             # exec('t_prime_list' + spec_ind_s + '.insert(0,1)')
# #             #
# #             # print(t_prime_list)
# #
# #
# #     t_prime_rule = tg.list_to_string(t_prime_list)
# #     for ch in ["N", "O"]:
# #         if ch in t_prime_rule:
# #             t_prime_rule = t_prime_rule.replace(ch, str(rd.choice(list(range(1, len(t_prime_bv)+1)))))
# #                     # print(n_ind_select)
# #         # ['Z.and_operator', 'Z.or_operator']
# #         # print(output)
# #
# #     print(t_rule)
# #     print(t_prime_rule)
# #             # elif t_component in ['Z.atleast','Z.atmost','Z.exactly']:
# #
# #     X = [{'id': 0, 'colour': 'blue', 'size': 1, 'xpos': 2, 'ypos': 4, 'rotation': 3.1, 'orientation': 'upright', 'contact': [0], 'grounded': 'no'}]
# #     # #
# #     t_proposal = Z.generate_res(start=t_prime_rule, productions=productions, bound_vars=t_bv)
# #     # print(tt['rule'])
# #     # print(tt['rule'])
# #     # print(eval(tt['rule']))
# #     return  spec_ind,
# #
# #
# # # print(rr.get_prec_recursively(t_prime_list))
# # # print(t_prime_list)
# # # print(tg.get_inds(t_prime_list))
# # for a in range(10):
# #     geta()
# def flattenList(listToFlatten, outerList, LIST):
#     for item in listToFlatten:
#         outerList.append(item)
#     outerList.remove(listToFlatten)
# x = ['Z.forall', ['lambda', 'x1', ':', 'Z.or_operator', [['Z.greater', ['x1', 'x1', 'size']], 'Z.lequal', ['x1', 1, 'size']], 'X']]
#
#
# flattenList(x[1][4][0], x[1][4], x)
# print(x)
