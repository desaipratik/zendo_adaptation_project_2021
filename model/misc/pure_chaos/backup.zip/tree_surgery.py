"""
Created on Tue Aug 12 15:56:00 2020

@author: jan-philippfranken
"""
###############################################################################
########################### Tree Surgery ######################################
###############################################################################

####################### General imports #######################################
import random as rd
import copy
import pandas as pd

####################### Custom imports ########################################
# from recode_rule_to_list import rule_translator
from reverse_rule import reverse_rule


class tree_surgery(reverse_rule):
    '''this fellow does some regrowing to a given tree'''
    def __init__self(self):
        self.__init__self(self)

    def flattenList(self, listToFlatten, outerList, LIST):
        for item in listToFlatten:
            outerList.append(item)
        outerList.remove(listToFlatten)

    def insertList(self, listToFlatten, outerList, LIST, insind):
        insind2=0
        for item in listToFlatten:
            outerList.insert(insind+insind2,item)
            insind2+=1
        outerList.remove(listToFlatten)

    def tree_surgery(self, t, productions, rep, rep_n):
        replacements = copy.deepcopy(rep)
        replacements_new = copy.deepcopy(rep_n)
        # t_rule = t['rule']
        t_rule = "Z.atmost(lambda x1: Z.exists(lambda x2: Z.and_operator(Z.equal(x2, 'blue','colour'),Z.equal(x2, 1, 'size')),X),3,X)"
        # t_bv = t['bv']
        t_bv = [['x1'], ['x1', 'x2']]
        t_prime_bv = t_bv
        t_prec = self.get_prec_recursively(self.string_to_list(t_rule))
        t_prime_bv = t_bv.copy()              # new bound variables (might be changed later)
        t_list = self.string_to_list(t_rule)  # transforming rule into list of list

        ind_nested = self.get_inds(t_list)      # gettinng elements and all nested indexes
        t_prod = t_prec["from"]

        # then sampling new node and replacements
        t_prod_inds = list(range(0, len(t_prod)))
        nt_inds = [index for index,prod in zip(t_prod_inds,t_prod) if prod in ['B', 'S', 'L', 'M']]
        nt_ind = rd.choice(nt_inds)     # selecting random nonterminal index from which tree will be regrown
        nt = t_prod[nt_ind]
        new_inds = [index for index,prod in zip(t_prod_inds,t_prod) if prod in [nt]] # getting indexes for B onl
        n_ind_select = new_inds.index(nt_ind)     # getting the exact B (ie which one from many has been chosen if many are available)
        all_inds = list(range(0, len(ind_nested)))
        nt_inds = [index for index,prod in zip(all_inds,ind_nested) if prod in replacements[nt]]
        spec_ind = ind_nested[nt_inds[n_ind_select]+1]
        spec_ind_l = [str([ind]) for ind in spec_ind]
        spec_ind_s = ''.join(spec_ind_l)
        t_prime_list = copy.deepcopy(t_list)

        t_component = eval('t_list' + spec_ind_s)
        # deleting the component to ensure new thing wont be the same

        del(replacements_new[nt][replacements[nt].index(t_component)])
        del(replacements[nt][replacements[nt].index(t_component)])
        p_ind = rd.choice(list(range(0, len(replacements[nt]))))
        new_p = replacements[nt][p_ind]
        exec('t_prime_list' + spec_ind_s + '=' + 'new_p')
        eval('print(t_list' + spec_ind_s + ')')


        # now conditional assignments:
        if nt == 'S':
            if t_component in ['Z.exists','Z.forall'] and new_p in ['Z.exists','Z.forall'] or t_component in ['Z.atleast','Z.atmost','Z.exactly'] and new_p in ['Z.atleast','Z.atmost','Z.exactly']:
                t_prime_prec = self.get_prec_recursively(t_prime_list)
                t_prime_rule = self.list_to_string(t_prime_list)
                return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
            elif t_component in ['Z.exists','Z.forall'] and new_p in ['Z.atleast','Z.atmost','Z.exactly']:
                if n_ind_select == 0:
                    t_prime_list[1][-1] = rd.choice(productions["M"])
                    t_prime_list[1].append('X')
                elif n_ind_select == 1:
                    t_prime_list[1][4][-1] = rd.choice(productions["M"])
                    t_prime_list[1][4].append('X')
                elif n_ind_select == 2:
                    t_prime_list[1][4][4][-1] = rd.choice(productions["M"])
                    t_prime_list[1][4][4].append('X')
                t_prime_prec = self.get_prec_recursively(t_prime_list)
                t_prime_rule = self.list_to_string(t_prime_list)
                return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
            elif t_component in ['Z.atleast','Z.atmost','Z.exactly'] and new_p in ['Z.exists','Z.forall']:
                if n_ind_select == 0:
                    del(t_prime_list[1][-2])
                elif n_ind_select == 1:
                    del(t_prime_list[1][4][-2])
                elif n_ind_select == 2:
                    del(t_prime_list[1][4][4][-2])
                t_prime_prec = self.get_prec_recursively(t_prime_list)
                t_prime_rule = self.list_to_string(t_prime_list)
                return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}


        if nt == 'L':
            t_prime_prec = self.get_prec_recursively(t_prime_list)
            t_prime_rule = self.list_to_string(t_prime_list)
            return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}

        if nt == 'M':
            if n_ind_select == 0:
                t_prime_list[1][-2] = rd.choice(replacements[nt])
            elif n_ind_select == 1:
                t_prime_list[1][4][-2] = rd.choice(replacements[nt])
            elif n_ind_select == 2:
                t_prime_list[1][4][4][-2] = rd.choice(replacements[nt])
            t_prime_prec = self.get_prec_recursively(t_prime_list)
            t_prime_rule = self.list_to_string(t_prime_list)
            return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}

        if nt == 'B':
            # first if boolean extension just replace
            if t_component in ['Z.and_operator', 'Z.or_operator'] and new_p in ['Z.and_operator', 'Z.or_operator']:
                t_prime_rule = self.list_to_string(t_prime_list)
                t_prime_prec = self.get_prec_recursively(t_prime_list)
                return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}

            # easy for not operator
            if new_p in ['Z.not_operator'] and t_component in ['Z.and_operator', 'Z.or_operator']:
                spec_ind_l_2 = spec_ind.copy()
                spec_ind_l_2[-1] = spec_ind_l_2[-1] + 1
                spec_ind_l_2.append(spec_ind_l_2[-1] + 2)
                spec_ind_l_2 = [str([i]) for i in spec_ind_l_2[:len(spec_ind_l_2)-2]] + spec_ind_l_2[len(spec_ind_l_2)-2:]
                final_index = '[' + str(spec_ind_l_2[-2]) + ':' + str(spec_ind_l_2[-1]) + ']'
                spec_ind_l_2[len(spec_ind_l_2)-2:] = final_index
                spec_ind_s_2 = ''.join(spec_ind_l_2)
                new_list_ind = spec_ind[-1] + 1
                spec_ind_l = spec_ind_l[:len(spec_ind_l)-1]
                spec_ind_s = ''.join(spec_ind_l)
                exec('t_prime_list' + spec_ind_s + '.insert(new_list_ind,t_component)')
                print(eval('t_prime_list' + spec_ind_s_2))
                exec('t_prime_list' +spec_ind_s_2+' = [t_prime_list' + spec_ind_s_2+']')


            elif new_p in ['Z.not_operator'] and t_component not in ['Z.and_operator', 'Z.or_operator']:
                spec_ind_l_2 = spec_ind.copy()
                spec_ind_l_2[-1] = spec_ind_l_2[-1] + 1
                spec_ind_l_2.append(spec_ind_l_2[-1] + 2)
                spec_ind_l_2 = [str([i]) for i in spec_ind_l_2[:len(spec_ind_l_2)-2]] + spec_ind_l_2[len(spec_ind_l_2)-2:]
                final_index = '[' + str(spec_ind_l_2[-2]) + ':' + str(spec_ind_l_2[-1]) + ']'
                spec_ind_l_2[len(spec_ind_l_2)-2:] = final_index
                spec_ind_s_2 = ''.join(spec_ind_l_2)
                new_list_ind = spec_ind[-1] + 1
                # spec_ind_l_2[-1] = str([new_list_ind])
                spec_ind_l = spec_ind_l[:len(spec_ind_l)-1]
                spec_ind_s = ''.join(spec_ind_l)
                exec('t_prime_list' + spec_ind_s + '.insert(new_list_ind,t_component)')
                exec('t_prime_list' +spec_ind_s_2+' = [t_prime_list' + spec_ind_s_2+']')

            # now check booleans vs single checks
            elif t_component in ['Z.and_operator', 'Z.or_operator'] and new_p in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']:
                print('tttttddddd')
                first_component = spec_ind_l.copy()
                first_component[-1] = str([spec_ind[-1] + 1])
                first_component.append('[0]')
                second_component = spec_ind_l.copy()
                second_component[-1] = str([spec_ind[-1] + 1])
                second_component.append('[2]')
                first_component_s = ''.join(first_component)
                second_component_s = ''.join(second_component)
                f_c = eval('t_list' + first_component_s)
                s_c = eval('t_list' + second_component_s)
                print(s_c)
                if new_p == f_c:
                    print('td1')
                    spec_ind_2 = first_component_s[:-3]
                    print(spec_ind_2)
                    exec('del(t_prime_list' + spec_ind_2 + '[2:])')
                    exec('del(t_prime_list' + spec_ind_s + ')')
                    spec_ind_2 = spec_ind_2[:-3]
                    print(t_prime_list)
                    spec_ind_3 = spec_ind_s
                    print(spec_ind_3)
                    print('adsfasdfafd')
                    print(spec_ind_2)
                    print(eval('t_prime_list' + spec_ind_2))
                    spec_ind_check = spec_ind_s[:-3]
                    if 'Z.not_operator' not in eval('t_prime_list' + spec_ind_check):
                        print('hacerrr')
                        spec_ind_2 = spec_ind_s[:-3]
                        self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))
                    else:
                        ind_not = eval('t_prime_list' + spec_ind_check +  '.index("Z.not_operator")')
                        ind_item = int(spec_ind_s[-2:-1])

                        print(ind_item)
                        mid_obj_ind = spec_ind_s[:-3] + str([int(spec_ind_s[-2])-1])
                        print(ind_not)
                        print(eval('t_prime_list'+mid_obj_ind))
                        if ind_item - 2 != ind_not or eval('t_prime_list'+mid_obj_ind) != 'Z.not_operator':
                            print('hacerino')
                            spec_ind_2 = spec_ind_s[:-3]
                            self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))



                elif new_p == s_c:
                    print('td2')
                    spec_ind_2 = second_component_s[:-3]
                    exec('del(t_prime_list' + spec_ind_2 + '[:3])')
                    spec_ind_3 = spec_ind_2 + '[0]'
                    self.flattenList(eval('t_prime_list' + spec_ind_3),eval('t_prime_list' + spec_ind_2),t_prime_list)
                    print(t_prime_list)

                elif new_p != f_c and new_p != s_c:
                    print('td3')
                    print(t_prime_list)
                    backuplist = copy.deepcopy(t_prime_list)
                    back_insert = eval('t_prime_list' + spec_ind_s)
                    exec('del(t_prime_list' + spec_ind_s + ')')
                    exec('del(t_prime_list' + spec_ind_s + '[:4])')
                    print('asf')
                    spec_ind_2 = spec_ind_s[:-3]
                    print(t_prime_list)
                    print(back_insert)
                    exec('t_prime_list' + spec_ind_2 + '.insert(3,"C")')
                    print(t_prime_list)
                    self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))
                    print(eval('t_prime_list' + spec_ind_2))
                    if [] in eval('t_prime_list' + spec_ind_2):
                        exec('t_prime_list' + spec_ind_2 + '.remove([])')
                    print(t_prime_list)
                    spec_ind_new = spec_ind_s[:-3]
                    # exec('t_prime_list' + spec_ind_new + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
                    # print(t_prime_list)
                    # print(spec_ind_s)




            # now check singles vs singles
            elif t_component in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater'] and new_p in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']:
                # check size comparison
                if t_component in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater'] and new_p in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.equal']:
                    # t_prime_prec = self.get_prec_recursively(t_prime_list)
                    t_prime_rule = self.list_to_string(t_prime_list)
                    # return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
                # check equal comparison vs size
                elif t_component in ['Z.equal'] and new_p in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater']:
                    # need to check if next item is size
                    size_check_ind = spec_ind_l.copy()
                    size_check_ind[-1] = str([spec_ind[-1] + 1])
                    size_check_ind_safe = size_check_ind.copy()
                    size_check_ind = size_check_ind + ['[2]']
                    size_check_ind_s = ''.join(size_check_ind)

                    if eval('t_prime_list' + size_check_ind_s) == 'size':
                        # t_prime_prec = self.get_prec_recursively(t_prime_list)
                        t_prime_rule = self.list_to_string(t_prime_list)
                        # return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
                    else:
                        size_check_ind_s = ''.join(size_check_ind_safe)
                        exec('del(t_prime_list' + size_check_ind_s + ')')
                        exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
                        # t_prime_prec = self.get_prec_recursively(t_prime_list)
                        t_prime_rule = self.list_to_string(t_prime_list)
                        # return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}

                elif t_component in ['Z.hor_operator'] and new_p in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.equal']:
                    exec('del(t_prime_list' + spec_ind_s + ')')
                    exec('del(t_prime_list' + spec_ind_s + '[:4])')
                    exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
                    # t_prime_prec = self.get_prec_recursively(t_prime_list)
                    t_prime_rule = self.list_to_string(t_prime_list)
                    # return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}

                elif t_component in ['Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.equal'] and new_p in ['Z.hor_operator']:
                    exec('del(t_prime_list' + spec_ind_s + ')')
                    exec('del(t_prime_list' + spec_ind_s + '[:4])')
                    exec('t_prime_list' + spec_ind_s + '= replacements[nt][p_ind] + ' + rd.choice(replacements_new[nt][p_ind]))
                    # t_prime_prec = self.get_prec_recursively(t_prime_list)
                    t_prime_rule = self.list_to_string(t_prime_list)
                    # return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}
            # finally expansion check
            elif t_component in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater'] and new_p in ['Z.and_operator', 'Z.or_operator']:
                spec_ind_l_2 = spec_ind.copy()
                spec_ind_l_2[-1] = spec_ind_l_2[-1] + 1
                spec_ind_l_2.append(spec_ind_l_2[-1] + 3)
                spec_ind_l_2 = [str([i]) for i in spec_ind_l_2[:len(spec_ind_l_2)-2]] + spec_ind_l_2[len(spec_ind_l_2)-2:]
                final_index = '[' + str(spec_ind_l_2[-2]) + ':' + str(spec_ind_l_2[-1]) + ']'
                spec_ind_l_2[len(spec_ind_l_2)-2:] = final_index
                spec_ind_s_2 = ''.join(spec_ind_l_2)
                new_list_ind = spec_ind[-1] + 1
                spec_ind_l = spec_ind_l[:len(spec_ind_l)-1]
                spec_ind_s = ''.join(spec_ind_l)
                inser_index = spec_ind_l_2.copy()
                inser_index[-4] = int(inser_index[-4]) + 2
                exec('t_prime_list' + spec_ind_s + '.insert(new_list_ind,t_component)')
                print(eval('t_prime_list' + spec_ind_s_2))
                exec('t_prime_list' + spec_ind_s + '.insert(inser_index[-4],"C")')
                exec('t_prime_list' +spec_ind_s_2+' = [t_prime_list' + spec_ind_s_2+']')
                # t_prime_prec = self.get_prec_recursively(t_prime_list)
                t_prime_rule = self.list_to_string(t_prime_list)
                # return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t_prime_prec, "t_prime_list": t_prime_list}

            # now what if old one was not operator -> delete this fellow:
            if t_component in ['Z.not_operator'] and new_p in ['Z.equal', 'Z.hor_operator', 'Z.lequal', 'Z.grequal', 'Z.less', 'Z.greater', 'Z.and_operator', 'Z.or_operator']:

                #just delete the fucking not operator and the replacement as well. thats what you will do
                # print(new_p)
                print('lenotmatethefuck')

                new_spec_ind = spec_ind.copy()
                new_spec_ind[-1] = new_spec_ind[-1] + 1
                new_spec_ind_2 = new_spec_ind.copy()
                new_spec_ind_2.append(1)
                new_spec_ind_l = [str([i]) for i in new_spec_ind]
                new_spec_ind_l_2 = [str([i]) for i in new_spec_ind_2]
                new_spec_ind_s = ''.join(new_spec_ind_l)
                new_spec_ind_s_2 = ''.join(new_spec_ind_l_2)
                t_prime_list2 = copy.deepcopy(t_prime_list)
                exec('del(t_prime_list' + spec_ind_s + ')')
                print(t_prime_list)
                print(spec_ind_s)
                print(eval('t_prime_list' + spec_ind_s))
                spec_ind_check = spec_ind_s[:-3]
                spec_ind_check_2 = spec_ind_check + '['+ str(int(spec_ind_check[-2])-2) + ']'
                print(spec_ind_check)
                print(eval('t_prime_list' + spec_ind_check))
                if 'Z.not_operator' not in eval('t_prime_list' + spec_ind_check):
                    print('hacerrr')
                    spec_ind_2 = spec_ind_s[:-3]
                    self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))

                elif 'Z.not_operator' in eval('t_prime_list' + spec_ind_check):
                    print('CRAVEr')
                    ind_not = eval('t_prime_list' + spec_ind_check +  '.index("Z.not_operator")')
                    print(ind_not)
                    ind_item = int(spec_ind_s[-2:-1])
                    print(ind_item)
                    if ind_item - 2 != ind_not and ind_item -1 != ind_not:
                        print('hacerino')
                        spec_ind_2 = spec_ind_s[:-3]
                        self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))
                        # if eval('t_prime_list' + spec_ind_check_2) != 'Z.not_operator':
                        #     print('laser')
                        #     spec_ind_2 = spec_ind_s[:-3]
                        #     self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))
                    else:

                        spec_ind_check = spec_ind_s[:-3]
                        spec_ind_check_2 = spec_ind_check[:-3]
                        item = eval('t_prime_list' + spec_ind_s)
                        item_out = eval('t_prime_list' + spec_ind_check)
                        item_out_out = eval('t_prime_list' + spec_ind_check_2)
                        print('meowing')
                        if item_out_out[item_out_out.index(item_out)-1] in ['Z.and_operator', 'Z.or_operator']:
                            print('vat in the houst')
                            ind_not = eval('t_prime_list' + spec_ind_check +  '.index("Z.not_operator")')
                            ind_item = int(spec_ind_s[-2:-1])
                            ind_other = item_out_out.index(item_out)-1
                            print(ind_other)
                            print(ind_item)
                            mid_obj_ind = spec_ind_s[:-3] + str([int(spec_ind_s[-2])-1])
                            print(ind_not)
                            print(eval('t_prime_list'+mid_obj_ind))
                            if ind_item - 2 != ind_not or eval('t_prime_list'+mid_obj_ind) != 'Z.not_operator':
                                print('hacerino')
                                spec_ind_2 = spec_ind_s[:-3]
                                self.insertList(eval('t_prime_list' + spec_ind_s),eval('t_prime_list' + spec_ind_2),t_prime_list,int(spec_ind_s[-2]))





                # flattenList(x[1][4][0], x[1][4], x)
                # exec('t_prime_list' + spec_ind_s + '= t_prime_list' + spec_ind_s + '[0]')
                print(t_prime_list)

                # spec_ind_3 = spec_ind_s[:-2] + str(int(spec_ind_s[-2]) + 1) + ']'
                # exec('t_prime_list' + spec_ind_2 + '.insert(4, t_prime_list2' + spec_ind_3 + '[1])')
                # print(t_prime_list)


        t_prime_rule = self.list_to_string(t_prime_list)
        for ch in ["N", "O"]:
            if ch in t_prime_rule:
                t_prime_rule = t_prime_rule.replace(ch, str(rd.choice(list(range(1, len(t_prime_bv)+1)))))

        # t_prime_rule = "Z.forall(lambda x1: Z.or_operator(Z.not_operator(Z.greater(x1,x1,'size')),(Z.not_operator(Z.hor_operator(x1,x1,'contact')))),X)"





        print('results')
        print(t_rule)
        print(t_prime_rule)
        print('vatvatvatvat')
        # print(t_prime_list)
        # t_prime_list = ['Z.forall', ['lambda', 'x1', ':', 'Z.forall', ['lambda', 'x2', ':', 'Z.exists', ['lambda', 'x3', ':', 'C', 'X'], 'X'], 'X']]
        # t_prime_prec = self.get_prec_recursively(t_prime_list)
        return {"t_prime_rule": t_prime_rule, "t_prime_bv": t_prime_bv, "t_prime_prec": t['prec'], "t_prime_list": t_prime_list}
